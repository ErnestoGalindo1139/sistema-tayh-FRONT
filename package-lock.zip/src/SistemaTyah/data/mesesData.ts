export const mesesData = [
  { id: 1, texto: 'Enero' },
  { id: 2, texto: 'Febrero' },
  { id: 3, texto: 'Marzo' },
  { id: 4, texto: 'Abril' },
  { id: 5, texto: 'Mayo' },
  { id: 6, texto: 'Junio' },
  { id: 7, texto: 'Julio' },
  { id: 8, texto: 'Agosto' },
  { id: 9, texto: 'Septiembre' },
  { id: 10, texto: 'Octubre' },
  { id: 11, texto: 'Noviembre' },
  { id: 12, texto: 'Diciembre' },
];
