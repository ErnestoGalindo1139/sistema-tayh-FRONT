import React, { useEffect, useState } from 'react';
import { DataTable } from '../components/DataTable';
import Toast from '../components/Toast';
import { EditIcon } from '../icons/EditIcon';
import { EyeIcon } from '../icons/EyeIcon';
import { AddIcon } from '../icons/AddIcon';
import { useTheme } from '../../ThemeContext';
import { IApiError } from '../interfaces/interfacesApi';
import { WaitScreen } from '../components/WaitScreen';
import { RetweetIcon } from '../icons/RetweetIcon';
import { Tooltip } from 'flowbite-react';
import {
  IFiltrosPedidos,
  IFormPedidos,
  IPedidos,
} from '../interfaces/interfacesPedidos';
import { getPedidos } from '../helpers/apiPedidos';
import { eliminarPedidoHelper } from '../helpers/pedidos/eliminarPedidoHelper';
import { IEstatus } from '../interfaces/interfacesEstatus';
import { getEstatus } from '../helpers/apiEstatus';
import { FormPedidos } from '../components/Pedidos/FormPedidos';
import { FiltrosPedidos } from '../components/Pedidos/FiltrosPedidos';
import { useForm } from '../hooks/useForm';
import { ModalCambiarEstatus } from '../dialogs/ModalCambiarEstatus';
import { PedidosExcel } from '../excel/PedidosExcel';
import { getFinMesActual, getInicioMesActual } from '../utils/fechas';

export const PedidosAdmin = (): React.JSX.Element => {
  const [pedidos, setPedidos] = useState<IPedidos[]>([]);
  const [pedido, setPedido] = useState<IFormPedidos>();

  const [estatusPedidos, setEstatusPedidos] = useState<IEstatus[]>([]);

  const [estatusPedidosFormulario, setEstatusPedidosFormulario] = useState<
    IEstatus[]
  >([]);

  const [isModalOpen, setIsModalOpen] = useState(false);

  const {
    formState: filtros,
    setFormState: setFiltros,
    onInputChange,
  } = useForm<IFiltrosPedidos>({
    id_Pedido: '',
    id_Cliente: '',
    fh_InicioPedido: getInicioMesActual(),
    fh_FinPedido: getFinMesActual(),
    fh_InicioEnvioProduccion: '',
    fh_FinEnvioProduccion: '',
    fh_InicioEntregaEstimada: '',
    fh_FinEntregaEstimada: '',
    nb_Cliente: '',
    id_Estatus: '',
  });

  const [sn_Editar, setSn_Editar] = useState<boolean>(false);
  const [sn_Visualizar, setSn_Visualizar] = useState<boolean>(false);
  const [sn_Agregar, setSn_Agregar] = useState<boolean>(false);

  const [isLoading, setIsLoading] = useState(false);

  const { isDarkMode } = useTheme();

  useEffect(() => {
    const fetchPedidos = async (): Promise<void> => {
      try {
        setIsLoading(true);
        const pedidosData = await getPedidos(filtros);
        setPedidos(pedidosData.body);
      } catch (error) {
        const errorMessage =
          (error as IApiError).message || 'Ocurrió un error desconocido';
        Toast.fire({
          icon: 'error',
          title: 'Ocurrió un Error',
          text: errorMessage,
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchPedidos();
  }, []);

  useEffect(() => {
    const fetchEstatusPedidos = async (): Promise<void> => {
      try {
        const estatusData = await getEstatus(4); // Modulo de Pedidos
        setEstatusPedidos(estatusData.body);
        setEstatusPedidosFormulario(estatusData.body);
      } catch (error) {
        const errorMessage =
          (error as IApiError).message || 'Ocurrió un error desconocido';
        Toast.fire({
          icon: 'error',
          title: 'Ocurrió un Error',
          text: errorMessage,
        });
      }
    };

    fetchEstatusPedidos();
  }, []);

  const columns: {
    id: keyof IPedidos;
    texto: string;
    visible: boolean;
    width: string;
    bgColor?: string;
    textAlign?: string;
  }[] = [
    { id: 'id_Pedido', texto: 'Folio Pedido', visible: true, width: '10%' },
    { id: 'id_Cliente', texto: 'Folio Cliente', visible: true, width: '10%' },
    { id: 'nb_Cliente', texto: 'Nombre Cliente', visible: true, width: '25%' },
    {
      id: 'fh_PedidoFormat',
      texto: 'Fecha Pedido',
      visible: true,
      width: '15%',
    },
    {
      id: 'fh_EnvioProduccionFormat',
      texto: 'Fecha Envío Producción',
      visible: true,
      width: '15%',
    },
    {
      id: 'fh_EntregaEstimadaFormat',
      texto: 'Fecha Entrega Estimada',
      visible: true,
      width: '15%',
    },
    {
      id: 'de_Estatus',
      texto: 'Estatus',
      visible: true,
      width: '10%',
      bgColor: 'color_Estatus',
      textAlign: 'center',
    },
  ];

  const esFinalizado = (row: IPedidos): boolean =>
    Number(row.id_Estatus) === 14;

  const actions = [
    {
      icono: <EyeIcon className="text-blue-500" />,
      texto: 'Visualizar',
      onClick: (row: IPedidos): void => {
        setSn_Editar(false);
        setSn_Visualizar(true);
        limpiarPedido();
        setPedido({
          ...row,
        });
      },
      width: '20%',
      isVisible: (): boolean => true, // siempre visible
    },
    {
      icono: <EditIcon className="text-[#a22694]" />,
      texto: 'Editar',
      onClick: (row: IPedidos): void => {
        setSn_Editar(true);
        setSn_Visualizar(false);
        limpiarPedido();
        setPedido({
          ...row,
        });
      },
      isVisible: (row: IPedidos): boolean => !esFinalizado(row), // ocultar si está finalizado
    },
    {
      icono: <RetweetIcon className="text-black" />,
      texto: 'Cambiar Estatus',
      onClick: (row: IPedidos): void => {
        setSn_Editar(false);
        setSn_Visualizar(false);
        setPedido({ ...row });
        abrirModalCambiarEstatus();
      },
      isVisible: (row: IPedidos): boolean => !esFinalizado(row), // ocultar si está finalizado
    },
  ];

  const limpiarPedido = (): void => {
    setPedido({
      id_Pedido: 0,
      id_Cliente: 0,
      fh_Pedido: '',
      fh_EnvioProduccion: '',
      fh_EntregaEstimada: '',
      id_ViaContacto: 0,
      de_ViaContacto: '',
      id_Estatus: '12',
      de_Estatus: '',
      im_Impuesto: 0,
      im_IVA: 0,
      im_ISR: 0,
      im_TotalImpuesto: 0,
      im_TotalIVA: 0,
      im_TotalISR: 0,
      im_TotalPedido: 0,
      im_SubTotal: 0,
      sn_EnvioDomicilio: 0,
      im_EnvioDomicilio: 0,
      pedidosDetalles: [],
    });
  };

  const eliminarPedido = async (id_Pedido: string): Promise<void> => {
    setIsLoading(true);
    const pedidosData = await eliminarPedidoHelper(id_Pedido, filtros);

    if (pedidosData.success) {
      setPedidos(pedidosData.body);
      setIsLoading(false);
    } else {
      return;
    }
  };

  const abrirModalCambiarEstatus = (): void => {
    setIsModalOpen(true);
  };

  const cerrarModalCambiarEstatus = (): void => {
    setIsModalOpen(false);
  };

  return (
    <>
      {isLoading && <WaitScreen message="cargando..." />}

      {sn_Agregar || sn_Visualizar || sn_Editar ? (
        <FormPedidos
          setSn_Agregar={setSn_Agregar}
          setSn_Visualizar={setSn_Visualizar}
          setSn_Editar={setSn_Editar}
          sn_Editar={sn_Editar}
          sn_Visualizar={sn_Visualizar}
          sn_Agregar={sn_Agregar}
          row={
            pedido
              ? pedido
              : {
                  id_Pedido: 0,
                  id_Cliente: 0,
                  fh_Pedido: '',
                  fh_EnvioProduccion: '',
                  fh_EntregaEstimada: '',
                  id_ViaContacto: 0,
                  de_ViaContacto: '',
                  id_Estatus: 12,
                  de_Estatus: '',
                  im_Impuesto: 0,
                  im_IVA: 0,
                  im_ISR: 0,
                  im_TotalImpuesto: 0,
                  im_TotalIVA: 0,
                  im_TotalISR: 0,
                  im_TotalPedido: 0,
                  im_SubTotal: 0,
                  sn_EnvioDomicilio: 0,
                  im_EnvioDomicilio: 0,
                  pedidosDetalles: [],
                }
          }
          actualizarPedidos={setPedidos}
          filtros={filtros}
          estatusPedidos={estatusPedidosFormulario}
        />
      ) : (
        <div className={isDarkMode ? 'dark' : ''}>
          <section className="content dark:bg-[#020405]">
            {/* contenedor */}
            <div className="flex items-center justify-between">
              <div className="dark:text-white">
                <h2 className="font-bold text-[2.5rem]">Pedidos</h2>
                <p className="text-[1.6rem]">
                  Aquí puedes gestionar los Pedidos.
                </p>
              </div>

              <div className="flex gap-2">
                <PedidosExcel filtros={filtros} estatus={estatusPedidos} />

                <Tooltip
                  content="Agregar Pedido"
                  className="text-[1.3rem]"
                  placement="bottom"
                >
                  <button
                    onClick={() => {
                      setSn_Agregar(true);
                      setSn_Editar(false);
                      setSn_Visualizar(false);
                      limpiarPedido();
                    }}
                  >
                    <AddIcon width="4em" height="4em" />
                  </button>
                </Tooltip>
              </div>
            </div>

            {/* Filtros */}
            <FiltrosPedidos
              filtros={filtros}
              setFiltros={setFiltros}
              estatusPedidos={estatusPedidos}
              actualizarPedidos={setPedidos}
              setIsLoading={setIsLoading}
              onInputChange={onInputChange}
            />

            <div className="table-container dark:bg-transparent">
              <DataTable
                data={pedidos}
                columns={columns}
                actions={actions}
                initialRowsPerPage={10}
              />
            </div>
          </section>
        </div>
      )}
      <ModalCambiarEstatus
        isOpen={isModalOpen}
        onClose={cerrarModalCambiarEstatus}
        actualizarPedidos={setPedidos}
        row={
          pedido
            ? pedido
            : {
                id_Pedido: 0,
                id_Cliente: 0,
                fh_Pedido: '',
                fh_EnvioProduccion: '',
                fh_EntregaEstimada: '',
                id_ViaContacto: 0,
                de_ViaContacto: '',
                id_Estatus: 12,
                de_Estatus: '',
                im_Impuesto: 0,
                im_IVA: 0,
                im_ISR: 0,
                im_TotalImpuesto: 0,
                im_TotalIVA: 0,
                im_TotalISR: 0,
                im_TotalPedido: 0,
                im_SubTotal: 0,
                sn_EnvioDomicilio: 0,
                im_EnvioDomicilio: 0,
                pedidosDetalles: [],
              }
        }
        id_Modulo={4}
      />
    </>
  );
};
