// Interfaces Dashboard
export interface IDashboard {
  id: string;
  titulo: string;
  valor: string;
  variacion: string;
  color: string;
  icono: string;
}
