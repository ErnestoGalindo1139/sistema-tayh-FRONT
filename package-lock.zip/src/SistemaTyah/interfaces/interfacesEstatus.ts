export interface IEstatus {
  id_Estatus: number;
  id_Modulo: string;
  de_Estatus: string;
  color_Estatus: string;
}

export interface IEstatusComboMultiSelect {
  id_Estatus: number;
  id_Modulo: number;
  de_Estatus: string;
}
