export interface IFiltrosModelos {
  id_Modelo: string;
  de_Genero: string;
  de_Modelo: string;
}

export interface IFormModelos {
  id_Modelo?: string;
  de_Genero: string;
  de_Modelo: string;
}
