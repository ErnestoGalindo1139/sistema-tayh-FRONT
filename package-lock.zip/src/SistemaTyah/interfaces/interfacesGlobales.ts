export interface CustomSelectValue {
  value: number;
  label: string;
}
