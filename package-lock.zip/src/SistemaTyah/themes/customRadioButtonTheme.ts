export const customRadioButtonTheme = {
  root: {
    base: 'h-8 w-8 border border-gray-500 text-cyan-600 focus:ring-2 focus:ring-cyan-500 dark:border-gray-600 dark:bg-gray-700 dark:focus:bg-cyan-600 dark:focus:ring-cyan-600 cursor-pointer',
  },
};
