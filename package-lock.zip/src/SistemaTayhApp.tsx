import { AppRouter } from './router/AppRouter';

export const SistemaTayhApp = () => {
  return (
    <>
      <AppRouter />
    </>
  );
};
